<?php
  include "cabecalho.html";
  require "conexao.php";
  require "models/historia.php";
  require "models/repositorio_historia.php";
  

  $repositorio_historia = new RepositorioHistoria($conexao);

   $rota = "lista_historia";


    if(array_key_exists("rota", $_GET)){
      $rota = (string) $_GET["rota"];
    }

    if(is_file("controllers/{$rota}.php")){
      require "controllers/{$rota}.php";
    }
    else{
      echo "Rota não encontrada";
    }
include "rodape.html";
 ?>