  <div class="container-fluid titulo">
  	<div class="row">
  	<div class="col-md-3">
  		<a class="direcionamento" href="index.php?rota=form_historia"><button class="btn botao-voltar">formulario</button></a>
  	</div>
  	<div class="col-md-9 fixo">
  	 Veja aqui toda sua historia
  	</div>
  </div>
    </div> 
 <div class="container-fluid">
 	
   <div class="row espaco-cima">
 		
		<?php foreach($historias as $historia): ?>
		<div class="col-md-3">
			<div class="row">
             <div class="col-md-12 text-center">
             	
             </div>
			</div>
		<div class="card-deck ">
		  <div class="card ">

		    <img class="card-img-top imagem" src="<?php echo $historia->getImg()?>" alt="Card image cap">
		    <div class="card-img-overlay">
		    	<div class="row">
		    	<div class="col-md-3">
		    	 <a class="direcionamento" href="index.php?rota=editar_historia&&id=<?php echo $historia->getId(); ?>"><div class="text-left">Editar</div></a>
		    	</div>
		    	<div class="col-md-6"></div>
		    	<div class="col-md-3">
            <a class="direcionamento" href="index.php?rota=delete&&id=<?php echo $historia->getId();?>">  <div class="card-title text-right">X</div></a>
         </div>
     </div>
		    </div>
		    <div class="card-body">
		      <h5 class="card-title"><?php echo $historia->getTitulo();?></h5>
		      <p class="card-text"><?php echo $historia->getDescricao();?></p>
              <?php 
             	$data = explode("-",$historia->getData());
                
             	?>
             	<p class="data">Dia <?php echo $data[2]; ?> do <?php echo $data[1];?> de <?php echo $data[0]; ?></p>
		    </div>

		  </div>
		  
		 </div>
		</div>
	
		<?php endforeach; ?>
	</div>
</div>