<div class="container">
	
  <div class="cartao espaco-cima">
  	<div class="row ">
  		<div class="col-md-12 text-right">
  		<a href="index.php?lista_historia"><button class="btn botao-ir">Histórias</button></a>
  	</div>
  	</div>
  <div class="row ">
  	<div class="col-md-12 text-center">
   <h2>Adicione sua História</h2>
   </div>
  </div>
 <form action="index.php?rota=adiciona_historia" method="post"  enctype="multipart/form-data">
	 <div class="row">
	  <div class="col-md-3"></div>
	  <div class="col-md-6">
	  	<label>Data do Momento</label>
	  	<input type="date" name="data" class="form-control is-valid">
	  </div>
	  </div>
	  <div class="row">
	  	 <div class="col-md-3"></div>
	   <div class="col-md-6">
	 

	    <label>Imagem</label>
	    <input type="file" name="img" class="form-control is-valid">
	   </div>
	  </div>
	  <div class="row">
	  	 <div class="col-md-3"></div>
	  	<div class="col-md-6">
	  		<label>Titulo</label>
	  		<input type="text" name="titulo" class="form-control is-valid">
	  	</div>
	  </div>
	  <div class="row">
	  	 <div class="col-md-3"></div>
	  	<div class="col-md-6">
	  		<label>Descrição</label>
	  		<textarea type="text" name="descricao" class="form-control is-valid"></textarea> 
	  	</div>
	  </div>
	  <button type="subimit" class="btn btn-block botao">Enviar</button> 

  </form>	
  </div>
</div>