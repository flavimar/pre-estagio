<div class="container">
	<button><a href="index.php?lista_historia">HISTORIAS</a></button>
  <div class="cartao">
  <div class="row ">
  	<div class="col-md-12 text-center">
   <h2>Edite sua História</h2>
   </div>
  </div>
 <form action="index.php?rota=atualiza_historia" method="post"  enctype="multipart/form-data">
 	 <div class="row">
           <input type="hidden" name="id" class="form-control" value="<?php echo $historia->getId() ?>" >
          </div>
	  <div class="row">
	  <div class="col-md-3"></div>
	  <div class="col-md-6">
	  	<label>Data do Momento</label>
	  	<input type="date" name="data" class="form-control is-valid" value="<?php echo $historia->getData(); ?>">
	  </div>
	  </div>
	  <div class="row">
	  	 <div class="col-md-3"></div>
	   <div class="col-md-6">
	 

	    <label>Imagem</label>
	    <input type="file" name="img" class="form-control is-valid" value="hidden">
	   </div>
	  </div>
	  <div class="row">
	  	 <div class="col-md-3"></div>
	  	<div class="col-md-6">
	  		<label>Titulo</label>
	  		<input type="text" name="titulo" class="form-control is-valid" value="<?php echo $historia->getTitulo();?>">
	  	</div>
	  </div>
	  <div class="row">
	  	 <div class="col-md-3"></div>
	  	<div class="col-md-6">
	  		<label>Descrição</label>
	  		<textarea type="text" name="descricao" class="form-control is-valid"><?php echo $historia->getDescricao();?></textarea> 
	  	</div>
	  </div>
	  <button type="subimit" class="btn btn-block botao">Enviar</button> 

  </form>	
  </div>
</div>