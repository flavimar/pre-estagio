<?php
  $historias = $repositorio_historia->busca_historias();
 
 require __DIR__."/../views/lista_historia.php";
?>