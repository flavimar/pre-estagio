<?php 
 $id= $_GET['id'];
 $repositorio_historia->remove($id);
require __DIR__."/../controllers/lista_historia.php";
?>