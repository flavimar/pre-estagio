<?php
        $id = $_POST["id"];
      echo $id;
       $historia_atualizada = new Historia();
	   $historia_atualizada->setId($_POST["id"]);
	   $historia_atualizada->setData($_POST["data"]);

       $historia_atualizada->setTitulo($_POST["titulo"]);
       $historia_atualizada->setDescricao($_POST["descricao"]);
    echo $historia_atualizada->getDescricao();
   
      $repositorio_historia->atualiza($historia_atualizada);

	 header('Location: index.php?rota=lista_historia');
?>