<?php
 $historia = $repositorio_historia->busca_historia($_GET["id"]);
require __DIR__."/../views/edita_historia.php";

?>