<?php
 
 require __DIR__."/../views/coloca_historia.php";
?>