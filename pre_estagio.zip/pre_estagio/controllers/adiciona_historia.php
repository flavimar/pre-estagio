<?php

        $data = $_POST['data'];
		$imagem_tudo = $_FILES['img'];
		$nome_imagem = $imagem_tudo['name'];
		$img = "img/".$nome_imagem;
		move_uploaded_file($imagem_tudo['tmp_name'],$img);
	
	    $titulo = $_POST['titulo'];
	    $descricao = $_POST['descricao'];

    $historia = new Historia($data,$img,$titulo,$descricao);
		$repositorio_historia->adiciona($historia);




	require __DIR__."/../controllers/lista_historia.php";

?>
