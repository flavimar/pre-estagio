<?php
class RepositorioHistoria{
		private $conexao;

		public function __construct($conexao){
			$this->conexao = $conexao;
		}
		public function adiciona($historia){
			$sql = "INSERT INTO historia (data, img, titulo, descricao) VALUES (:data, :img, :titulo, :descricao)";

			$query = $this->conexao->prepare($sql);

			//executa o SQL
			$query->execute(['data'=>$historia->getData(),'img'=>$historia->getImg(),'titulo'=>$historia->getTitulo(),'descricao'=>$historia->getDescricao()]);
		}
		public function busca_historias(){

			$sql = "SELECT * FROM historia";

			$resultado = $this->conexao->query($sql, PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Historia');

            $historias = [];

            foreach($resultado as $historia){
                $historias[] = $historia;
            }

   			return $historias;
		}
		public function busca_historia($id){
$sql = "SELECT * FROM historia WHERE id=:id";

			$query = $this->conexao->prepare($sql);

			$query->execute(['id'=>$id]);


       $query->setFetchMode(PDO::FETCH_CLASS|PDO::FETCH_PROPS_LATE, 'Historia');
       $historia = $query->fetch();
			return $historia;
		}
		public function atualiza($historia){
			echo $historia->getTitulo();
			$sql = "UPDATE historia SET data = :data, titulo = :titulo, descricao = :descricao WHERE id = :id";

			$query = $this->conexao->prepare($sql);

			//executa o SQL
			$query->execute(['data'=>$historia->getData(),'titulo'=>$historia->getTitulo(),'descricao'=>$historia->getDescricao(),'id'=>$historia->getId()]);
		}
		public function remove($id){
			$sql = "DELETE FROM historia WHERE id = :id";

			$query = $this->conexao->prepare($sql);

			$query->execute(['id'=>$id]);
		}
}
?>