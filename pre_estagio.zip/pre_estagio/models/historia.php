<?php
 class Historia{
   private $id;
   private $data;
   private $img;
   private $titulo;
   private $descricao;

  	
  	function __construct($data = "", $img = "", $titulo = "", $descricao = "" ){
  			$this->data = $data;
  			$this->img = $img;
  			$this->titulo = $titulo;
  			$this->descricao = $descricao;
  	}
  public function setId($id){
  	$this->id = $id;
  }
  public function getId(){
  	return $this->id;
  }
  public function setData($data){
  	$this->data = $data;
  }
  public function getData(){
  	return $this->data;
  }
  public function setImg($img){
  	$this->img = $img;
  }
  public function getImg(){
  	return $this->img;
  }
  public function setTitulo($titulo){
  	$this->titulo = $titulo;
  }
  public function getTitulo(){
  	return $this->titulo;
  }
  public function setDescricao($descricao){
  	$this->descricao = $descricao;
  }
  public function getDescricao(){
  	return $this->descricao;
  }

 }


?>